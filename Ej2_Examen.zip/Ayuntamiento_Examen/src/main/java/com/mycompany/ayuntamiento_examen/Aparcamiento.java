/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ayuntamiento_examen;

/**
 *
 * @author DAW
 */
public abstract class Aparcamiento {

    protected int PARCodigo;
    protected String PARNombrePar;
    protected String PARdistrito;

    public Aparcamiento(int PARCodigo, String PARNombrePar, String PARdistrito) {
        this.PARCodigo = PARCodigo;
        this.PARNombrePar = PARNombrePar;
        this.PARdistrito = PARdistrito;
    }

    public int getPARCodigo() {
        return PARCodigo;
    }

    public void setPARCodigo(int PARCodigo) {
        this.PARCodigo = PARCodigo;
    }

    public String getPARNombrePar() {
        return PARNombrePar;
    }

    public void setPARNombrePar(String PARNombrePar) {
        this.PARNombrePar = PARNombrePar;
    }

    public String getPARdistrito() {
        return PARdistrito;
    }

    public void setPARdistrito(String PARdistrito) {
        this.PARdistrito = PARdistrito;
    }

}
