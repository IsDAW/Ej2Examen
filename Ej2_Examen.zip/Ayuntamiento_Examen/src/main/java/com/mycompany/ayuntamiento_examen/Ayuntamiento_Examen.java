/*
EJERCICIO 2 EXAMEN
 */
package com.mycompany.ayuntamiento_examen;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author DAW
 */
public class Ayuntamiento_Examen {

    public static void main(String[] args) {

        try {

            File archivo = new File("examen_ej2.txt");//CREA EL FICHERO
            System.out.println("Archivo encontrado: " + archivo.exists());

            Scanner lectorArchivo = new Scanner(archivo);//LEE EL FICHERO

            ArrayList Listado_Rotacion = new ArrayList();
            ArrayList Listado_Mixto = new ArrayList();
            ArrayList Listado_Residentes = new ArrayList();
            ArrayList Listado_Disuasorio = new ArrayList();

            HashMap<String, Integer> aparcamientos_distrito = new HashMap<String, Integer>();

            while (lectorArchivo.hasNext()) {//MIENTRAS HAYA ALGO,SEGUIRA LEYENDO

                //reset variables
                int codigo = 0;
                String nombre = "";
                String tipo = "";
                int plazas_rot = 0;
                int plazas_resi = 0;
                int plazas_disu = 0;
                String distrito = "";

                String linea = lectorArchivo.nextLine();
                String[] caso = linea.split(",");//array

                if ("ROTACIÓN".equals(caso[2])) {//INTRODUCE EN LISTADO ROTACION

                    int codigo_int = Integer.parseInt(caso[0]);
                    int plazas_rot_int = Integer.parseInt(caso[3]);

                    codigo = codigo_int;
                    nombre = caso[1];
                    tipo = caso[2];
                    plazas_rot = plazas_rot_int;
                    distrito = caso[6];

                    //Llena el mapa con el distrito,si ya existe le suma 1
                    if (aparcamientos_distrito.get(distrito) == null) {
                        aparcamientos_distrito.put(distrito, 1);
                    } else {
                        int cantidad = aparcamientos_distrito.get(distrito) + 1;
                        aparcamientos_distrito.put(distrito, cantidad);
                    }

                    Rotacion Tipo_Rotacion = new Rotacion(plazas_rot, codigo, nombre, distrito);
                    Listado_Rotacion.add(Tipo_Rotacion);

                } else if ("MIXTO".equals(caso[2])) {//INTRODUCE EN LISTADO MIXTO
                    int codigo_int = Integer.parseInt(caso[0]);
                    int plazas_rot_int = Integer.parseInt(caso[3]);
                    int plazas_resi_int = Integer.parseInt(caso[4]);

                    codigo = codigo_int;
                    nombre = caso[1];
                    tipo = caso[2];
                    plazas_rot = plazas_rot_int;
                    plazas_resi = plazas_resi_int;
                    distrito = caso[6];

                    //Llena el mapa con el distrito,si ya existe le suma 1
                    if (aparcamientos_distrito.get(distrito) == null) {
                        aparcamientos_distrito.put(distrito, 1);
                    } else {
                        int cantidad = aparcamientos_distrito.get(distrito) + 1;
                        aparcamientos_distrito.put(distrito, cantidad);
                    }

                    Mixto Tipo_Mixto = new Mixto(plazas_resi, plazas_rot, codigo, nombre, distrito);
                    Listado_Rotacion.add(Tipo_Mixto);

                } else if ("RESIDENTES".equals(caso[2])) {//INTRODUCE EN LISTADO RESIDENTES
                    int codigo_int = Integer.parseInt(caso[0]);
                    int plazas_resi_int = Integer.parseInt(caso[4]);

                    codigo = codigo_int;
                    nombre = caso[1];
                    tipo = caso[2];
                    plazas_resi = plazas_resi_int;
                    distrito = caso[6];

                    //Llena el mapa con el distrito,si ya existe le suma 1
                    if (aparcamientos_distrito.get(distrito) == null) {
                        aparcamientos_distrito.put(distrito, 1);
                    } else {
                        int cantidad = aparcamientos_distrito.get(distrito) + 1;
                        aparcamientos_distrito.put(distrito, cantidad);
                    }

                    Residentes Tipo_Residentes = new Residentes(plazas_resi, codigo, nombre, distrito);
                    Listado_Rotacion.add(Tipo_Residentes);

                } else if ("DISUASORIO".equals(caso[2])) {
                    int codigo_int = Integer.parseInt(caso[0]);
                    int plazas_disu_int = Integer.parseInt(caso[5]);

                    codigo = codigo_int;
                    nombre = caso[1];
                    tipo = caso[2];
                    plazas_disu = plazas_disu_int;
                    distrito = caso[6];

                    //Llena el mapa con el distrito,si ya existe le suma 1
                    if (aparcamientos_distrito.get(distrito) == null) {
                        aparcamientos_distrito.put(distrito, 1);
                    } else {
                        int cantidad = aparcamientos_distrito.get(distrito) + 1;
                        aparcamientos_distrito.put(distrito, cantidad);
                    }

                    Residentes Tipo_Residentes = new Residentes(plazas_disu, codigo, nombre, distrito);
                    Listado_Rotacion.add(Tipo_Residentes);

                }

            }
            lectorArchivo.close();

            //MUESTRA CUANTOS APARCAMIENTOS DE CADA TIPO HAY
            System.out.println("Hay " + Listado_Rotacion.size() + " de tipo ROTACION");
            System.out.println("Hay " + Listado_Mixto.size() + " de tipo MIXTO");
            System.out.println("Hay " + Listado_Residentes.size() + " de tipo RESIDENTE");
            System.out.println("Hay " + Listado_Disuasorio.size() + " de tipo DISUASORIO");

            //Muestra cuantos aparcamientos por distrito hay
            for (Map.Entry<String, Integer> entry : aparcamientos_distrito.entrySet()) {
                System.out.println("Distrito: " + entry.getKey() + ", Cantidad: " + entry.getValue());
            }

        } catch (FileNotFoundException | IllegalArgumentException e) {
            System.out.println("Excepcion: " + e);
        } catch (IOException e) {
            System.out.println("Excepcion: " + e);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
