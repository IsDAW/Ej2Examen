/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ayuntamiento_examen;

/**
 *
 * @author DAW
 */
public class Rotacion extends Aparcamiento {

    private int PARplazasRotacion;

    public Rotacion(int PARplazasRotacion, int PARCodigo, String PARNombrePar, String PARdistrito) {
        super(PARCodigo, PARNombrePar, PARdistrito);
        this.PARplazasRotacion = PARplazasRotacion;
    }

    public int getPARplazasRotacion() {
        return PARplazasRotacion;
    }

    public void setPARplazasRotacion(int PARplazasRotacion) {
        this.PARplazasRotacion = PARplazasRotacion;
    }

}
